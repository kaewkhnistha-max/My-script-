import express from "express";
import cors from "cors";
import "dotenv/config";

const app = express();
app.use(cors());
app.use(express.json({ limit: "32kb" }));

app.get("/health", (_req, res) => res.json({ ok: true, name: "NEXUS AI" }));

app.post("/chat", async (req, res) => {
  try {
    const { messages } = req.body ?? {};
    if (!Array.isArray(messages) || messages.length === 0) {
      return res.status(400).json({ error: "messages must be a non-empty array" });
    }
    if (!process.env.AI_API_KEY || !process.env.AI_API_URL || !process.env.AI_MODEL) {
      return res.status(503).json({ error: "Server AI settings are not configured" });
    }

    const system = {
      role: "system",
      content: "คุณคือ NEXUS AI ฉลาด วิเคราะห์เก่ง ตอบภาษาไทยเป็นธรรมชาติ กวนเล็กน้อยอย่างเป็นมิตร ไม่หยาบคาย และให้ความสำคัญกับความถูกต้อง"
    };
    const upstream = await fetch(process.env.AI_API_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.AI_API_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        model: process.env.AI_MODEL,
        messages: [system, ...messages.slice(-20)]
      })
    });

    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) {
      console.error("AI provider error:", upstream.status, data);
      return res.status(502).json({ error: "AI provider request failed" });
    }

    const reply = data?.choices?.[0]?.message?.content;
    if (typeof reply !== "string" || !reply.trim()) {
      return res.status(502).json({ error: "AI provider returned an empty response" });
    }
    res.json({ reply });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

const port = Number(process.env.PORT || 3000);
app.listen(port, () => console.log(`NEXUS server listening on ${port}`));
