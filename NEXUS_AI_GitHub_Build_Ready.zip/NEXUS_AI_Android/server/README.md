# NEXUS backend

1. ติดตั้ง Node.js 20 หรือใหม่กว่า
2. ในโฟลเดอร์นี้ รัน `npm install`
3. คัดลอก `.env.example` เป็น `.env`
4. กรอก `AI_API_KEY`, `AI_API_URL`, `AI_MODEL` ของผู้ให้บริการที่รองรับรูปแบบ Chat Completions
5. รัน `npm start`
6. Deploy หลัง HTTPS ก่อนนำ URL ไปใส่ใน Android `Config.kt`

ทดสอบสถานะได้ที่ `GET /health`

**ความปลอดภัยก่อนใช้งานจริง:** เพิ่ม rate limit, authentication, quota, logging ที่ไม่เก็บข้อมูลส่วนตัวเกินจำเป็น และจำกัด CORS ตามโดเมนที่ใช้ อย่าเปิด endpoint สาธารณะโดยไม่มีการป้องกัน และอย่า commit `.env`
