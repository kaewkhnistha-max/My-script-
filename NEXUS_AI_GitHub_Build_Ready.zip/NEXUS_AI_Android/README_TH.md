# NEXUS AI — Android starter project

โปรเจกต์เริ่มต้นสำหรับแอปแชต AI บน Android (Kotlin + Jetpack Compose)
พร้อม backend ตัวอย่างเพื่อเก็บ API key ไว้ฝั่งเซิร์ฟเวอร์ ไม่ฝัง key ลงใน APK

## สิ่งที่มีในชุดนี้
- หน้าจอแชตธีมมืด ชื่อ NEXUS AI
- บุคลิก: ฉลาด วิเคราะห์เก่ง และกวนแบบพอดี
- ส่งข้อความจาก Android ไปยัง backend
- backend Node.js ตัวอย่างที่เรียก API แบบ OpenAI-compatible
- API key อยู่ใน environment variable ของ backend เท่านั้น

## สำคัญ
นี่คือ **ซอร์สโปรเจกต์** ไม่ใช่ไฟล์ APK ที่คอมไพล์เสร็จแล้ว
ต้อง Build ด้วย Android Studio และตั้งค่า backend/API ก่อนจึงจะคุยกับ AI ออนไลน์ได้
อย่าใส่ API key ลงในแอป Android เพราะสามารถถูกดึงออกจาก APK ได้

## วิธีเริ่ม
1. ติดตั้ง Android Studio รุ่น stable
2. เปิดโฟลเดอร์ `android` ด้วย Android Studio
3. รอ Gradle sync แล้วกด Run เพื่อทดสอบบนมือถือ/Emulator
4. เปิดโฟลเดอร์ `server` แล้วทำตาม `server/README.md`
5. ตั้งค่า `BASE_URL` ใน `android/app/src/main/java/com/nexusai/app/Config.kt`
   ให้เป็น URL ของ backend (มือถือจริงต้องเข้าถึง URL นั้นได้)
6. เมื่อต้องการไฟล์ APK: Build > Build Bundle(s) / APK(s) > Build APK(s)

## ข้อจำกัดเริ่มต้น
- Android cleartext HTTP ถูกปิดไว้ ควรใช้ HTTPS กับ backend จริง
- ถ้าทดสอบ backend ในเครื่องเดียวกันบน Android Emulator ใช้ `10.0.2.2`
  แต่ถ้าเป็นมือถือจริงให้ใช้ IP ในเครือข่ายเดียวกันหรือ deploy backend ผ่าน HTTPS
- ค่า URL ตัวอย่างเป็น placeholder ต้องเปลี่ยนก่อนใช้งานจริง
