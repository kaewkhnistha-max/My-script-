package com.nexusai.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class ChatMessage(val text: String, val fromUser: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusChatScreen() }
    }
}

@Composable
fun NexusChatScreen() {
    val messages = remember {
        mutableStateListOf(ChatMessage("โย่ว! NEXUS ออนไลน์แล้ว 😏 มีอะไรให้สมองกลช่วย?", false))
    }
    var input by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF58D7FF),
        background = Color(0xFF080D18),
        surface = Color(0xFF111A2B)
    )) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFF080D18)).padding(16.dp)
        ) {
            Text("NEXUS AI", color = Color(0xFF58D7FF), fontSize = 27.sp)
            Text("ฉลาดเป็นงาน กวนเป็นบางเวลา", color = Color.LightGray, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages) { msg ->
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = if (msg.fromUser) Arrangement.End else Arrangement.Start
                    ) {
                        Surface(
                            color = if (msg.fromUser) Color(0xFF164A66) else Color(0xFF182338),
                            shape = RoundedCornerShape(16.dp),
                            modifier = Modifier.widthIn(max = 310.dp)
                        ) {
                            Text(msg.text, color = Color.White, modifier = Modifier.padding(12.dp))
                        }
                    }
                }
                if (busy) item { Text("NEXUS กำลังคิด...", color = Color(0xFF58D7FF)) }
            }
            error?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 12.sp) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("พิมพ์ข้อความถึง NEXUS...") },
                    maxLines = 4
                )
                Spacer(Modifier.width(8.dp))
                Button(
                    enabled = input.isNotBlank() && !busy,
                    onClick = {
                        val prompt = input.trim()
                        input = ""
                        messages.add(ChatMessage(prompt, true))
                        busy = true
                        error = null
                        scope.launch {
                            val result = withContext(Dispatchers.IO) { askNexus(messages.toList()) }
                            if (result.first != null) messages.add(ChatMessage(result.first!!, false))
                            else error = result.second ?: "เชื่อมต่อไม่สำเร็จ"
                            busy = false
                        }
                    }
                ) { Text("ส่ง") }
            }
        }
    }
}

private val http = OkHttpClient.Builder()
    .connectTimeout(20, TimeUnit.SECONDS)
    .readTimeout(60, TimeUnit.SECONDS)
    .build()

private fun askNexus(history: List<ChatMessage>): Pair<String?, String?> {
    return try {
        val arr = JSONArray()
        arr.put(JSONObject().put("role", "system").put(
            "content",
            "คุณคือ NEXUS AI ผู้ช่วยภาษาไทยที่ฉลาด วิเคราะห์เก่ง อธิบายชัดเจน " +
            "มีอารมณ์ขันและกวนเล็กน้อยอย่างเป็นมิตร แต่สุภาพและจริงจังเมื่อจำเป็น"
        ))
        history.takeLast(20).forEach {
            arr.put(JSONObject()
                .put("role", if (it.fromUser) "user" else "assistant")
                .put("content", it.text))
        }
        val body = JSONObject().put("messages", arr).toString()
            .toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url(Config.BASE_URL.trimEnd('/') + "/chat")
            .post(body)
            .build()
        http.newCall(request).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) return Pair(null, "เซิร์ฟเวอร์ตอบกลับ ${response.code}: ตรวจ backend/API")
            val json = JSONObject(raw)
            Pair(json.optString("reply", "NEXUS ยังไม่มีคำตอบ"), null)
        }
    } catch (e: Exception) {
        Pair(null, "เชื่อมต่อไม่ได้: ${e.localizedMessage ?: "ตรวจอินเทอร์เน็ตและ URL"}")
    }
}
