package com.nexusai.app

object Config {
    // เปลี่ยนเป็น HTTPS URL ของ backend ที่ deploy แล้ว เช่น https://api.example.com
    // ห้ามใส่ API key ในแอป Android
    const val BASE_URL = "https://YOUR-BACKEND-DOMAIN"
}
